# Synthesis Exporter Web UI
This is a React + TS project to build a webpage that will be run in a [Palette](https://help.autodesk.com/view/fusion360/ENU/?guid=GUID-6C0C8148-98D0-4DBC-A4EC-D8E03A8A3B5B) inside of fusion

For developing in Fusion, use `bun run dev` to automatically recompile your output. You should also enable the web developer tools (see the "Debugging" section of the [palettes help article](https://help.autodesk.com/view/fusion360/ENU/?guid=GUID-6C0C8148-98D0-4DBC-A4EC-D8E03A8A3B5B))

If you're only making changes to the frontend and don't require fusion, you can use `bun run dev:ui` to open it in your browser