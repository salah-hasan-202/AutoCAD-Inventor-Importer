"""
Container for all options pertaining to the Fusion Exporter.
These options are saved per-design and are passed to the parser upon design export.
"""

import json
import os
import platform
from dataclasses import dataclass, field, fields
from typing import Any

import adsk.core
from adsk.fusion import CalculationAccuracy, TriangleMeshQualityOptions

from src import INTERNAL_ID
from src.Logging import getLogger, logFailure, timed
from src.Types import (
    KG,
    ExportLocation,
    ExportMode,
    Gamepiece,
    Joint,
    ModelHierarchy,
    PhysicalDepth,
    Wheel,
    encodeNestedObjects,
    makeObjectFromJson,
)


@dataclass
class ExporterOptions:
    # Python's `os` module can return `None` when attempting to find the home directory if the
    # user's computer has conflicting configs of some sort. This has happened and should be accounted
    # for accordingly.
    fileLocation: str | os.PathLike[str] | None = field(
        default=(os.getenv("HOME") if platform.system() == "Windows" else os.path.expanduser("~"))
    )
    name: str | None = field(default=None)
    version: str | None = field(default=None)
    materials: int = field(default=0)
    exportMode: ExportMode = field(default=ExportMode.ROBOT)
    wheels: list[Wheel] = field(default_factory=list)
    joints: list[Joint] = field(default_factory=list)
    gamepieces: list[Gamepiece] = field(default_factory=list)
    tags: dict[str, str] = field(default_factory=dict)
    robotWeight: KG = field(default=KG(0.0))
    autoCalcRobotWeight: bool = field(default=False)
    autoCalcGamepieceWeight: bool = field(default=False)

    frictionOverride: bool = field(default=False)
    frictionOverrideCoeff: float = field(default=0.5)

    compressOutput: bool = field(default=True)
    exportAsPart: bool = field(default=False)

    exportLocation: ExportLocation = field(default=ExportLocation.DOWNLOAD)
    openSynthesisUponExport: bool = field(default=False)

    hierarchy: ModelHierarchy = field(default=ModelHierarchy.FusionAssembly)
    visualQuality: TriangleMeshQualityOptions = field(default=TriangleMeshQualityOptions.LowQualityTriangleMesh)
    physicalDepth: PhysicalDepth = field(default=PhysicalDepth.AllOccurrence)
    physicalCalculationLevel: CalculationAccuracy = field(default=CalculationAccuracy.LowCalculationAccuracy)

    @logFailure
    @timed
    def readFromDesign(self) -> "ExporterOptions":
        designAttributes = adsk.core.Application.get().activeProduct.attributes
        for field in fields(self):
            attribute = designAttributes.itemByName(INTERNAL_ID, field.name)
            if attribute:
                attrJsonData = makeObjectFromJson(field.type, json.loads(attribute.value))
                setattr(self, field.name, attrJsonData)

        self.visualQuality = TriangleMeshQualityOptions.LowQualityTriangleMesh
        return self

    @logFailure
    @timed
    def readFromJSON(self, data: dict[str, Any]) -> "ExporterOptions":
        for field in fields(self):
            attribute = data.get(field.name)
            if attribute is not None:
                attrJsonData = makeObjectFromJson(field.type, attribute)
                setattr(self, field.name, attrJsonData)

        self.visualQuality = TriangleMeshQualityOptions.LowQualityTriangleMesh
        return self

    @logFailure
    @timed
    def writeToDesign(self) -> None:
        designAttributes = adsk.core.Application.get().activeProduct.attributes
        for field in fields(self):
            data = json.dumps(getattr(self, field.name), default=encodeNestedObjects, indent=4)
            designAttributes.add(INTERNAL_ID, field.name, data)

    @logFailure
    @timed
    def writeToJson(self) -> dict[str, Any]:
        out = {}
        for field in fields(self):
            data = json.dumps(getattr(self, field.name), default=encodeNestedObjects, indent=4)
            out[field.name] = json.loads(data)
        return out
