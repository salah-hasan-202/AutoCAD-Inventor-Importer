# Synthesis Exporters

## Officially Supported Exporters

### Synthesis Fusion Addin

An Autodesk® Fusion™ addin to export assemblies into the [Mirabuf](https://github.com/HiceS/mirabuf) format.

See [README](/exporter/SynthesisFusionAddin).
