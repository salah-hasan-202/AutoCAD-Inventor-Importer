# Synthesis Simulation

A collection of simulation tools and samples to help enhance the use of code simulation inside of Synthesis.

## SyntheSim

SyntheSim is a utility used to bolster the simulation capabilities of WPILib compatible libraries commonly used in FRC today.

## Samples

This directory includes sample projects that are simulation compatible with Synthesis. These sample projects give
users an idea of how to configure their own projects to best take advantage of simulation.
