---
name: Internal Dev Sprint Card
about: Cards for GitHub Projects
title: ''
labels: sprint
assignees: ''

---

|    DOD    | Done |    Asignees    | Branch | PR |
|-----------|------|----------------|-------|-----|
| Status    | ❌ | <assignee> | <branchName> | <number> |
