![Synthesis: An Autodesk Technology](/engine/Assets/Resources/Branding/Synthesis/Synthesis-An-Autodesk-Technology-2023-lockup-Blk-OL-No-Year-stacked.png#gh-light-mode-only)
![Synthesis: An Autodesk Technology](/engine/Assets/Resources/Branding/Synthesis/Synthesis-An-Autodesk-Technology-2023-lockup-Wht-OL-No-Year-stacked.png#gh-dark-mode-only)

# Synthesis Contribution Guide

Synthesis is 100% open source and relies on the FIRST community to help shape its growth. The Synthesis Contribution Guide suggests ways in which you can get involved through development and non-development avenues.

# How to Contribute

Before you contribute to this repository, please first discuss the change you wish to make a GitHub issue or reach out through our [community Discord](https://www.discord.gg/hHcF9AVgZA). This way we can ensure that there is no overlap between outside contributors and internal development work.

When ready to contribute, fork the Synthesis repository, make your changes, and submit a pull request. When contributing to Synthesis, please branch from and submit to our `dev` branch. The `prod` branch is intended to be a copy of either exactly what is in production, or what is ready for production. We like to keep changes to the dev branch so they have time to simmer and be distributed via beta releases.

Be sure to fill out the pull request template accordingly to make reviewing your work as smooth as possible.

# Why Contribute? Benefits to Contributing

- Prepare for an internship - share your contributions when applying to the [Synthesis Summer Internship.](https://synthesis.autodesk.com/internship.html)
- Add your contributions to Synthesis: An Autodesk Technology to your portfolio
- Meet other members of the FIRST community
- Get involved and learn more about Autodesk products
- Improve a product that you care about - if you use Synthesis and notice a feature you want, get involved!

# How to Contribute

### Found a bug? Have an idea for a feature?

Please [contact us](#Contact-Us) to let us know about the issue or feature!

_A Note to Developers_: Please first discuss the change you wish to make via issue, email, or any other method with the owners of this repository before making a change. This way, we can ensure that there is no overlap between contributions and internal development work. You may contact us using any of [these methods](#Contact-Us), although email is preferred in this case.

For smaller changes, just submit a pull request and be sure to follow the PR template to create a clear and detailed description of the changes you've made.

### Submit a CAD Model

Submit your team's CAD model to be added to the Synthesis robot and field libraries by emailing your designs to frc@autodesk.com. Please share them in the form of a Fusion360 Share-link. Raw Mirabuf files will not be accepted.

### Write Tutorials, Increase Documentation

We are always interested in ways to make our tutorials and documentation clearer for our end users. If there is content missing or could be refined, please follow our [contribution guidelines](#How-to-Contribute) for submitting a change.

### Translate our Tutorials and Documentation

If you or someone you know can read and write in another language, we would like to translate our text-based resources to make them available in more languages. Contact frc@autodesk.com for more details.

### Create How-To or Project DIY and Inspiration Guides

Did you add a feature to Synthesis, or learn how to use a specific feature? Write a how-to guide or [share your project with us](#Contact-Us).

### Share Your Use Case

Hearing how you use Synthesis is valuable feedback to our team. Share your use cases by tagging us [@synthesis.adsk](https://www.instagram.com/synthesis.adsk/) on Instagram, posting on [ChiefDelphi](https://www.chiefdelphi.com/), or talking about it on [our Discord](https://discord.gg/FuuQ9UGycM).

### Expand FIRST Support

FIRST control systems and essentials like sensors, cameras, various motors, etc. would greatly increase simulation support. Learn more about [contributing development here](#How-to-Contribute).

### Beta Testing

Help us try and break Synthesis! At the end of summer development, we provide a Synthesis beta for users to test and sometimes in exchange for your time we offer incentives to users. You can stay up-to-date with any Synthesis releases by joining our [Discord server](https://www.discord.gg/hHcF9AVgZA) and/or following us on Instagram [@synthesis.adsk](https://www.instagram.com/synthesis.adsk/).

### Contact Us

| Platform    |                                  Link                                  |
| :---------- | :--------------------------------------------------------------------: |
| Discord     |      [Synthesis Community Discord](https://discord.gg/FuuQ9UGycM)      |
| Email       |              [frc@autodesk.com](mailto:frc@autodesk.com)               |
| Instagram   |      [@synthesis.adsk](https://www.instagram.com/synthesis.adsk/)      |
| Reddit      |    [u/synthesis_adsk](https://www.reddit.com/user/synthesis_adsk/)     |
| ChiefDelphi | [synthesis_adsk](https://www.chiefdelphi.com/u/synthesis_adsk/summary) |

To let us know about an issue with Synthesis, you can submit a [GitHub issue](https://github.com/Autodesk/synthesis/issues/new/choose).
