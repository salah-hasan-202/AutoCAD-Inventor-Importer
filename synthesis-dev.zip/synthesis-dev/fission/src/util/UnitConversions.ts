export function convertFeetToMeters(feet: number): number {
    return feet * 0.3048
}
