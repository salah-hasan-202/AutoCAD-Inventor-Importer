interface TaskStatus {
    isDone: boolean
    message: string
    progress: number
}

export default TaskStatus
