export enum ContactType {
    ROBOT_ENTERS = "Opponent Robot Enters",
    ANY_ROBOT_INSIDE = "Collision with Any Robot Inside",
    BOTH_ROBOTS_INSIDE = "Collision with Both Robots Inside",
    RED_ROBOT_INSIDE = "Collision with Red Robot Inside",
    BLUE_ROBOT_INSIDE = "Collision with Blue Robot Inside",
}
