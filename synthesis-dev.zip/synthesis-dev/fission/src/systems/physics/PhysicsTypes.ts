export type JoltBodyIndexAndSequence = number

export const PAUSE_REF_ASSEMBLY_SPAWNING = "assembly-spawning"
export const PAUSE_REF_ASSEMBLY_CONFIG = "assembly-config"
export const PAUSE_REF_ASSEMBLY_MOVE = "assembly-move"
