# Physics System Documentation

This Physics System is our interface with [Jolt](https://jrouwe.github.io/JoltPhysics/), ensuring objects are properly handled and providing utility functions that are more custom-fit to our purposes.
