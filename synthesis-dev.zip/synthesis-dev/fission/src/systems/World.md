# World System Documentation

The world serves as a hub for all of the core systems. It is a static class that handles system update execution order and lifetime.
