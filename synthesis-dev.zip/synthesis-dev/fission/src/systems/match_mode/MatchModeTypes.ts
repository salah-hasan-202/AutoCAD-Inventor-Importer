export enum MatchModeType {
    SANDBOX = "Sandbox",
    AUTONOMOUS = "Autonomous",
    TELEOP = "Teleop",
    ENDGAME = "Endgame",
    MATCH_ENDED = "Match Ended",
}
