# Codelabs

These are the markdown files for the codelabs.

## Build

### Dependencies

1. [Go](https://go.dev/doc/install)
2. [Claat](https://pkg.go.dev/github.com/googlecodelabs/tools/claat#section-readme)
3. [Nodejs](https://nodejs.org/en/download/)

### Create Codelabs

`claat export -o ./[tutorial]Codelab [tutorial].md`

or

`make`

or

`make [tutorial]`

#### Make Script

Using the make script will dump all the resulting codelabs into an `out/` directory.

## Usage

Upload these to their correct locations on the web server. Ask [@KyroVibe](https://github.com/KyroVibe) or contact a subteam lead.
